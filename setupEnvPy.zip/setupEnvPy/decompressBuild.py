#!/usr/bin/env python
import os
import platform
import zipfile
import tarfile
import logging

logger = logging.getLogger('setupEnv.decompressBuild')

def decompressBuild(buildList, sysUname):
    for onefile in buildList:
        if 'Linux' in sysUname:
            logger.info('*** tar - decrompress .tar.gz file: ' + onefile)
            tar = tarfile.open(onefile)
            tar.extractall(".")
            tar.close()
        elif 'Windows' in sysUname:
            logger.info('*** zip - decrompress .zip file: ' + onefile)
            zfile = zipfile.ZipFile(onefile)
            zfile.extractall('.')
            zfile.close()
    logger.info('All the files have been decompressed.')
