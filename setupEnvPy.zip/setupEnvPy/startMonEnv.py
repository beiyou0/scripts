import time
import logging
import monUtil

logger = logging.getLogger('setupEnv.startMonEnv')

# note: Here we start monitor SA server twice in order to make cognos completely start
def startMonEnv(adminUser, adminPwd, sysUname):
    result = ''
    monHome = '/opt/IBM/MonServer/v8.5'
    cmdStart = monHome + '/profiles/WBMon01/bin/startServer.sh server1'
    cmdStop = monHome + '/profiles/WBMon01/bin/stopServer.sh server1'
    if 'Windows' in sysUname:
        monHome = 'C:/IBM/MonServer/v8.5'
        cmdStart = monHome + '/profiles/WBMon01/bin/startServer.bat server1'
        cmdStop = monHome + '/profiles/WBMon01/bin/stopServer.bat server1'
    if 'ppc64le' in sysUname:
        monHome = '/opt/ibm/MonServer/v8.5'
        cmdStart = monHome + '/profiles/WBMon01/bin/startServer.sh server1'
        cmdStop = monHome + '/profiles/WBMon01/bin/stopServer.sh server1'

    cmdStop = cmdStop + ' -user ' + adminUser + ' -password ' + adminPwd

    # start monitor server (1st)
    logger.info('*** start monitor server 1st time')
    result = monUtil.runSystemCmd(cmdStart)
    logger.info(result)

    # stop monitor server (1st)
    logger.info('*** stop monitor server')
    time.sleep(60)
    result = monUtil.runSystemCmd(cmdStop)
    logger.info(result)

    # re-start monitor server (2nd)
    logger.info('*** re-start monitor server 2nd time and wait 2mins here for cognos start-up')
    result = monUtil.runSystemCmd(cmdStart)
    logger.info(result)
    logger.info('Start wait for cognos: %s' % time.ctime())
    time.sleep(120)
    logger.info('End wait for cognos: %s' % time.ctime())


    
