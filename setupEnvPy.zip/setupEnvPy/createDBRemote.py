#!/usr/bin/env python
import os
import paramiko
import logging

logger = logging.getLogger('setupEnv.createDBRemote')

def sshExecCmd(ip, user, password, cmd):
    logger.info('--- Method Name: sshExecCmd: %s ' % cmd)
    result = ''
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ip, 22, user, password)
    stdin, stdout, stderr = ssh.exec_command(cmd)
    for line in stdout.readlines():
        result += line
    ssh.close()
    return result


def uploadDir(sftp, localDir, remoteDir):
    sftp.chdir(remoteDir)

    for f in os.listdir(localDir): 
        src = os.path.join(localDir, f)   
        if os.path.isfile(src):
            dst = remoteDir + '/' + f
            logger.info('upload file: ' + dst)
            sftp.put(src, dst)
        elif os.path.isdir(src):
            try:
                remoteDir = remoteDir + '/' + f
                sftp.mkdir(remoteDir)                     #create the next level directory
            except:
                logger.error('ERROR: the dir already exists: ' % remoteDir)
            uploadDir(sftp, src, remoteDir)
            sftp.chdir('..')                             #get back the the upper level directory for other dirs
            remoteDir = sftp.getcwd()
            # print 'new working remote dir is : ', remoteDir



def uploadDirSFTP(ip, user, password, localDir='./', remoteDir ='./'):
    logger.info('--- Method Name: uploadDirSFTP')
    t = paramiko.Transport((ip, 22))
    t.connect(username=user, password=password, hostkey=None)
    sftp = paramiko.SFTPClient.from_transport(t)

    sftp.mkdir(remoteDir)
    uploadDir(sftp, localDir, remoteDir)
    t.close()

# For now it can only create database (db2) when db2 is installed on linux
# Both remote and local
def createDBRemote(ip, dbName, dbUserId, dbPassword, user, password, sysUname):
    result = ''
    cogdbcripts = ''
    profileHome = '/opt/IBM/MonServer/v8.5/profiles/WBMon01'
    if 'Windows' in sysUname:
        profileHome = 'C:/IBM/MonServer/v8.5/profiles/WBMon01'
    if 'ppc64le' in sysUname:
        profileHome = '/opt/ibm/MonServer/v8.5/profiles/WBMon01'
        cogdbcripts = profileHome + '/Cognos'

    dbscripts = profileHome + '/dbscripts'

    remoteDir = '/opt/dbMonTmp'
    remoteCogDir = '/opt/dbCogTmp'

    logger.info('*** delete dbscripts folder if it exists on remote db server')
    cmd = 'rm -rf /opt/dbMonTmp /opt/dbCogTmp'
    result = sshExecCmd(ip, user, password, cmd)

    logger.info('*** copy dbscripts to database server')
    uploadDirSFTP(ip, user, password, dbscripts, remoteDir)
    if cogdbcripts != '':
        uploadDirSFTP(ip, user, password, cogdbcripts, remoteCogDir)

    logger.info('*** use db2 user to remotely log on db server')
    logger.info('*** ssh run db2 -tvf command to create monitor&cognos database')
    monDBDir = '/opt/dbMonTmp/Monitor/DB2'
    cogDBDir = '/opt/dbMonTmp/Cognos/DB2'
    bspaceDBDir = '/opt/dbMonTmp/BusinessSpace'
    if 'ppc64le' in sysUname:
        monDBDir = '/opt/dbMonTmp/DB2'
        cogDBDir = '/opt/dbCogTmp/DB2'

    logger.info('*** (1) create monitor database and tables')
    cmd = 'db2 -tf ' + monDBDir + '/createDatabase.sql;'    \
        + 'db2 connect to ' + dbName + ' user ' + dbUserId + ' using ' + dbPassword + ';'    \
        + 'db2 -tf ' + monDBDir + '/createTables.sql'
    result = sshExecCmd(ip, dbUserId, dbPassword, cmd)
    logger.info(result)

    logger.info('*** (2) create cognos database')
    cmd = 'db2 -tf ' + cogDBDir + '/createDatabase.sql'
    result = sshExecCmd(ip, dbUserId, dbPassword, cmd)
    logger.info(result)

    logger.info('*** (3) create BusinessSpace tables')
    bspaceDBDir = bspaceDBDir + '/' + os.listdir(profileHome + '/dbscripts/BusinessSpace')[0] + '/DB2/' + dbName
    cmd = 'db2 connect to ' + dbName + ' user ' + dbUserId + ' using ' + dbPassword + ';'    \
        + 'db2 -tf ' + bspaceDBDir + '/createTable_BusinessSpace.sql;'    \
        + 'db2 -tf ' + bspaceDBDir + '/createGrant_BusinessSpace.sql'
    result = sshExecCmd(ip, dbUserId, dbPassword, cmd)
    logger.info(result)


