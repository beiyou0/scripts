import os
import logging
import platform
import monUtil

logger = logging.getLogger('setupEnv.createSAProfile')

def createSAProfile(sysUname, dbSchemaName, dbName, dbUserId, dbPassword, dbHost, dbPort, dbCogName, adminUser, adminPwd):
    logger.info('*** create one stand-alone profile')
    # There are some hard code here since install root is using the silence install response file shipped with product.
    monHome = '/opt/IBM/MonServer/v8.5'
    cmd = monHome + '/bin/manageprofiles.sh '
    if 'Windows' in sysUname:
        monHome = 'C:/IBM/MonServer/v8.5'
        cmd = monHome + '/bin/manageprofiles.bat '
    if 'ppc64le' in sysUname:
        monHome = '/opt/ibm/MonServer/v8.5'
        cmd = monHome + '/bin/manageprofiles.sh '
      
    cmd = cmd + '-create -templatePath ' + monHome + '/profileTemplates/wbmonitor/default '    \
        + '-profileName WBMon01 '     \
        + '-profilePath ' + monHome + '/profiles/WBMon01 '    \
        + '-wbmDBType DB2_DATASERVER '    \
        + '-wbmDBDelayConfig true '    \
        + '-wbmDBOutputScriptDir ' + monHome + '/profiles/WBMon01/dbscripts '    \
        + '-wbmDBSchemaName ' + dbSchemaName.upper() + ' '    \
        + '-wbmDBName ' + dbName.upper() + ' '    \
        + '-wbmDBUserId ' + dbUserId + ' '    \
        + '-wbmDBPassword ' + dbPassword + ' '    \
        + '-wbmDBJDBCClasspath ' + monHome + '/jdbcdrivers/DB2/ '    \
        + '-wbmDBHostName ' + dbHost + ' '    \
        + '-wbmDBServerPort ' + dbPort + ' '    \
        + '-wbmCongosCreateNewServerDB true '    \
        + '-wbmCognosDBName ' + dbCogName.upper() + ' '    \
        + '-wbmCognosDBUserName ' + dbUserId + ' '    \
        + '-wbmCognosDBPassword ' + dbPassword + ' '    \
        + '-enableAdminSecurity true '    \
        + '-adminUserName ' + adminUser + ' -adminPassword ' + adminPwd + ' '    \
        + '-configureBSpace true'

    result = monUtil.runSystemCmd(cmd)
    logger.info(result)
    return result


