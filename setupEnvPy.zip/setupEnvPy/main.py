#!/usr/bin/env python
import os
import platform
import logging

import monUtil
import downloadBuild
import decompressBuild
import installBuild
import createSAProfile
import createDBRemote
import startMonEnv
import deployShowcase


def logInit():
    # create logger with 'setupEnv'
    logger = logging.getLogger('setupEnv')
    logger.setLevel(logging.DEBUG)
    # create file handler which logs even debug messages
    fh = logging.FileHandler('setupenv.log')
    fh.setLevel(logging.DEBUG)
    # create console handler with a higher log level
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    # add the handlers to the logger
    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


if __name__ == '__main__':

    logger = logInit()
    sysUname = platform.uname()

    logger.info('****************** Start Setup Environment ******************')
    # read config variable
    host, dir_root, dirn, filelist, user, password,   \
    dbSchemaName, dbName, dbUserId, dbPassword, dbHost, dbPort, dbCogName, dbSrvUser, dbSrvPwd,    \
    adminUser, adminPwd, ipAddr, port    \
    = monUtil.readConfig('mon.conf')

    filelist = eval(filelist)   # Must DO: turn list string into real list

    # step #1: download build
    logger.info('********** Step #1: download build **********')
    downloadBuild.downloadBuild(host, user, password, dir_root, dirn, filelist, sysUname)

    # step #2: decompress build
    logger.info('********** Step #2: decompress build **********')
    cwd = os.getcwd()
    logger.info('*** working directory is: -- build dir ' + cwd)
    buildList = os.listdir(cwd)
    decompressBuild.decompressBuild(buildList, sysUname)

    # step #3: silence install build
    logger.info('********** Step #3: silence install build **********')
    result = installBuild.installBuild(cwd, sysUname)


    # step #4: silence create SA profile
    logger.info('********** Step #4: silence create SA profile **********')
    result = createSAProfile.createSAProfile(sysUname, dbSchemaName, dbName, dbUserId, dbPassword,     \
                                                dbHost, dbPort, dbCogName, adminUser, adminPwd)


    # step #5: copy db2-dbscripts to db server and then create db 
    # Note: for now, it only support linux platform db2
    logger.info('********** Step #5: create database on remote/local db2 server (linux) **********')
    createDBRemote.createDBRemote(dbHost, dbName,  dbUserId, dbPassword, dbSrvUser, dbSrvPwd, sysUname)


    # step #6: start environment
    # Note: On Linux, cognos may need re-start once (according to infocenter)
    logger.info('********** Step #6: start monitor environment **********')
    startMonEnv.startMonEnv(adminUser, adminPwd, sysUname)

    # step #7: install showcase model and send events
    logger.info('********** Step #7: install showcase model and send events **********')
    os.chdir('..')
    cwd = os.getcwd()
    logger.info('*** working directory is: -- return to root-work dir ' + cwd)
    deployShowcase.deployShowcase(adminUser, adminPwd, ipAddr, port, sysUname)

    logger.info('****************** Complete Setup Environment ******************')










