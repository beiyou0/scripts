import os
import platform
import shutil
import logging
import monUtil

logger = logging.getLogger('setupEnv.installBuild')

def findAndBakResponseFile(extractDir, sysUname):
    resDir = extractDir + '/responsefiles/BusMon'
    if os.path.exists(resDir) and os.path.isdir(resDir):
        resfList = os.listdir(resDir)
        matchStr = '_root_64bit.xml'
        if 'Windows' in sysUname:
            matchStr = '_admin_64bit.xml'
        for f in resfList:
            if matchStr in f:
                responsefile = os.path.join(resDir, f)
                break;
        bakfile = responsefile + '.bak'
        logger.info('*** Back up the response file - filename: ' + bakfile)
        shutil.copy(responsefile, bakfile)
    else:
        logger.info('*** The extraced build files have something wrong. Please check build first.')
        
    return responsefile

def silenceInstall(extractDir, sysUname, responsefile):
    if 'Linux' in sysUname:
        cmd = extractDir + '/IM64/installc '
        if "ppc64le" in sysUname:
            cmd = extractDir + '/IM/installc '
    elif 'Windows' in sysUname:
        cmd = extractDir + '/IM64/installc.exe '
    else:
        logger.warn('system platform is others. please check.')

    cmd = cmd    \
        + '-acceptLicense input ' + responsefile + ' -log ./silence_install.log'

    result = monUtil.runSystemCmd(cmd)
    return result


def installBuild(extractDir, sysUname):
    # find response file in order to silence install
    responsefile = findAndBakResponseFile(extractDir, sysUname)
    logger.info('*** The response file for silence install is: ' + responsefile)

    # silence install product
    result = silenceInstall(extractDir, sysUname, responsefile)
    logger.info(result)
    return result