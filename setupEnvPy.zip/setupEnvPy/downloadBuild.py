#!/usr/bin/env python
import ftplib
import os
import socket
import logging

logger = logging.getLogger('setupEnv.downloadBuild')

class FTPSync(object):
    conn = ftplib.FTP()    # static variable

    def __init__(self, host, port=21):
        self.conn.connect(host, port)

    def login(self, username, password):
        self.conn.login(username, password)
        self.conn.set_pasv(False)
        logger.info(self.conn.welcome)

    def listDir(self, ftpPath):
        dir_res = []
        self.conn.dir(ftpPath, dir_res.append)
        dirs = [k.split(None, 8)[-1] for k in dir_res if k.startswith('d')]
        return dirs

    def cwdDir(self, ftpPath):
        try:
            self.conn.cwd(ftpPath)
        except ftplib.error_perm:
            logger.error('ERROR: cannot CD to "%s"' % ftpPath)
            self.conn.quit()
            return
        logger.info('*** Changed to "%s" folder' % ftpPath)

    def downloadFile(self, file):
        try:
            self.conn.retrbinary('RETR %s' % file, open(file, 'wb').write)
        except ftplib.error_perm:
            logger.error('ERROR: cannot read file "%s"' % file)
            os.unlink(file)
        else:
            logger.info('*** Downloaded "%s" to CWD' % file)

    def quit(self):
        self.conn.quit()
    
def downloadBuild(host, user, password, dir_root, dirn, filelist, sysUname):

    # step1: login ftp
    ftp = FTPSync(host)
    ftp.login(user, password)

    # step2: change to latest build dir and create local dir
    dirs = ftp.listDir(dir_root)
    latestBuild = dirs[-1]
    dirn = dir_root + dirn.replace('@latest@', latestBuild)
    ftp.cwdDir(dirn)

    try:
        os.mkdir(latestBuild)
    except OSError:
        pass
    os.chdir(latestBuild)

    # step3: download monitor build files
    for onefile in filelist:
        if "Windows" in sysUname:
            onefile = onefile.replace("@platform@", "windows.x86") + ".zip"            # windows x86
        elif "Linux" in sysUname and 'x86_64' in sysUname:
            onefile = onefile.replace("@platform@", "linux.x86") + ".tar.gz"           # linux x86
        elif "Linux" in sysUname and 'ppc64' in sysUname:
            onefile = onefile.replace("@platform@", "linux.ppc") + ".tar.gz"           # linux on Power (ppc ppc64)
        elif "Linux" in sysUname and "ppc64le" in sysUname:
            onefile = onefile.replace("@platform@", "linux.ppc64le") + ".tar.gz"       # linux on Power LE (Little Endion)
        elif "Linux" in sysUname and 's390x' in sysUname:
            onefile = onefile.replace("@platform@", "linux.zSeries") + ".tar.gz"
        else:
            logger.warn('Other System')
        logger.info('Will download file: ' + onefile)
        ftp.downloadFile(onefile)

    logger.info('All build files have been downloaded.')
    ftp.quit()

