# Here is a sample script that specifies values for each of the IBM Business Monitor installation tasks.
# For each install task, the fields must be passed in the correct order.
# To see the list of fields for a task, start wsadmin and run this command:
#   print AdminApp.taskInfo( '<path_to_ear_file>', '<task_name>' )
# For example:
#   print AdminApp.taskInfo( 'C:/temp/ClipsAndTacksApplication.ear', 'LifecycleClientDatabaseTask' )

# The LifecycleClientDatabaseTask task consists of the following 14 fields
# and the acceptable values:
#   "Run scripts to create the schema" = yes or no
#      default is yes
#   "Run scripts to enable Data Movement Services" = yes or no
#      default is no
#   "Run scripts to delete the schema during uninstallation" = yes or no
#      default is no unless the server is running in development mode
#   "Processing strategy" = SerialST or SerialMT
#       SerialST means "6.0.2 emulation"
#       SerialMT means "scalable"; this is the default
#   "Enable event reordering" = yes or no
#      default is no
#   "Enable KPI merge from previous version" = yes or no
#      default is yes
#   "Enable Business Situations merge from previous version" = yes or no
#      default is yes
#   "Is profile migration in process" = should always be no
#   "Generate Dashboard during monitor model installation" = yes or no
#      Defaults to yes if the server is in development mode and 
#      no if the server is not in development mode
#   "User to add for Business Space dashboard = user name 
#      Defaults to no additional user is added
#   "Name of Business Space dashboard" = dashboard name
#      Defaults to Model Name and version
#   "First field reserved for use by automatically generated models" = no
#      should always be no
#   "Second field reserved for use by automatically generated models" = no
#      should always be no
#   "Field reserved for use by custom models" = no
#      should always be no

createSchema = 'yes'
enableDMS = 'no'
deleteSchema = 'yes'
processingStrategy = 'SerialMT'
eventReordering = 'no'
kpiMerge = 'yes'
businessSituation = 'yes'
profileMigration = 'no'
generateDashboard = 'no'
dashboardUserid = '' 
dashboardName = '' 

databaseTaskInfo = [ createSchema, enableDMS, deleteSchema, processingStrategy, eventReordering, kpiMerge, businessSituation, profileMigration, generateDashboard, dashboardUserid, dashboardName ]

# The LifecycleClientCognosTask task consists of the following field
# and the acceptable values:
#   "Publish Cognos cube package" = yes or no
#      default is yes

publishCubes = 'yes'

cognosTaskInfo = [ publishCubes ]

# The LifecycleClientEventSourceTask task consists of the following 3 fields
# and the acceptable values:
#   Local event transport mode = ModelScopedIncomingEvents, VersionScopedIncomingEvents or blank  for auto-detect
#      default is auto-detect ()
#   List of remote event source IDs, separated by commas
#      for example, DEF-hostname1Cell01,DEF-hostname2Cell01
#      default is no assigned event sources ()
#   Event Consumption mode for model version = Inactive or CreateNewInstances
#      default is Inactive
# 
# To get a list of available event sources you can use:
#   AdminTask.wbmListCeiEventSources() or
#   AdminTask.wbmListDefEventSources() depending on the type of event sources the model is expecting

eventTransport = ''
eventSourceList = AdminTask.wbmListCeiEventSources().replace('\n',',')
eventConsumption = 'CreateNewInstances'

eventTaskInfo = [ eventTransport, eventSourceList, eventConsumption ]
# The LifecycleClientDataSecurityTask task consists of the following 3 fields
# and the acceptable values:
#   "Create Resource Group" = existing or creating
#      default is existing
#   "Data Security resource group name" = name of resource group
#      default is root
#   "Resource Group Description" = description of resource group
#      only used when creating a resource group
#   "User name" = the user name to be assigned to a role
#   "User role" = the role for the user name
#      for example, KPI-Administrator

createResource = 'existing'
groupName = 'root'
groupDesc = ''
userName = 'admin'
userRole = 'KPI-Administrator'

securityTaskInfo = [ createResource, groupName, groupDesc, userName, userRole ]

# Turn on tracing if needed
# print AdminControl.trace('com.ibm.wbimonitor.*=all=enabled')

# Example of specifying values for 1 install task
#AdminApp.install(earName, ['-LifecycleClientEventSourceTask', [eventTaskInfo]]

# Example of specifying values for 2 install tasks
#AdminApp.install(earName,  ['-LifecycleClientDatabaseTask', [databaseTaskInfo], \
#   '-LifecycleClientEventSourceTask', [eventTaskInfo]]  )

# Example of specifying values for 3 install tasks
#AdminApp.install(earName,  ['-LifecycleClientDatabaseTask', [databaseTaskInfo], \
#   '-LifecycleClientCognosTask', [cognosTaskInfo], \
#   '-LifecycleClientCEITask', [ceiTaskInfo] ] )

# Example of specifying values for 4 install tasks
AdminApp.install('@bpmHome@/installableApps.wbm/showcase/model/BetterLenderApplication.ear',  ['-LifecycleClientDatabaseTask', [databaseTaskInfo], \
   '-LifecycleClientCognosTask', [cognosTaskInfo], \
   '-LifecycleClientEventSourceTask', [eventTaskInfo], \
   '-LifecycleClientDataSecurityTask', [securityTaskInfo]] )

# Save the app
AdminConfig.save()