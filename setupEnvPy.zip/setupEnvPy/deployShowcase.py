#!/usr/bin/env python
import os
import time
import logging
import monUtil

logger = logging.getLogger('setupEnv.deployShowcase')

def installShowcase(adminUser, adminPwd, sysUname):
    monHome = '/opt/IBM/MonServer/v8.5'
    cmd = monHome + '/profiles/WBMon01/bin/wsadmin.sh '
    if 'Windows' in sysUname:
        monHome = 'C:/IBM/MonServer/v8.5'
        cmd = monHome + '/profiles/WBMon01/bin/wsadmin.bat '
    if 'ppc64le' in sysUname:
        monHome = '/opt/ibm/MonServer/v8.5'
        cmd = monHome + '/profiles/WBMon01/bin/wsadmin.sh '

    cmd = cmd + '-lang jython -user ' + adminUser + ' -password ' + adminPwd    
    valDict = {'@bpmHome@': monHome}
    monUtil.replaceOnefile('installShowcaseSA.py', valDict)
    cmd = cmd + ' -f installShowcaseSA.py'

    result = monUtil.runSystemCmd(cmd)
    logger.info(result)


def sendEventsToShowcase(adminUser, adminPwd, ipAddr, port, sysUname):
    monHome = '/opt/IBM/MonServer/v8.5'
    cmd = monHome + '/profiles/WBMon01/bin/wsadmin.sh '
    if 'Windows' in sysUname:
        monHome = 'C:/IBM/MonServer/v8.5'
        cmd = monHome + '/profiles/WBMon01/bin/wsadmin.bat '
    if 'ppc64le' in sysUname:
        monHome = '/opt/ibm/MonServer/v8.5'
        cmd = monHome + '/profiles/WBMon01/bin/wsadmin.sh '

     # try to find 1st-year directory under install_root/installableApps.wbm/showcase/events/allevents
    eventDir = monHome + '/installableApps.wbm/showcase/events/allevents'
    dirs = os.listdir(eventDir)
    firstYearDir = eventDir + '/' + dirs[0]
    logger.info('The first year showcase model events directory is: ' + firstYearDir)

    cmd = cmd    \
        + '-wsadmin_classpath ' + monHome + '/installableApps.wbm/showcase/scripts/lib/monShowcase.jar '    \
        + '-lang jython '   \
        + '-user ' + adminUser + ' '    \
        + '-password ' + adminPwd + ' '    \
        + '''-c "from com.ibm.wbimonitor.utility.emitter import RestEventEmitter" '''    \
        + '-c "RestEventEmitter.emitEvents(\\"' + ipAddr + '\\",' + port + ',\\"' + firstYearDir + '\\",\\"' + adminUser + '\\",\\"' + adminPwd + '\\")"'

    result = monUtil.runSystemCmd(cmd)
    logger.info(result)



def deployShowcase(adminUser, adminPwd, ipAddr, port, sysUname):
    logger.info('*** Step #7.1: replace values & install showcase model ******')

    installShowcase(adminUser, adminPwd, sysUname)

    # ****** Step #7.2: time sleep to wait model application to start (1min Here)
    logger.info('****** Step #7.2: time sleep to wait model app to start (Here 1min) ******')
    logger.info('Start wait for app: %s' % time.ctime())
    time.sleep(60)
    logger.info('End wait for app: %s' % time.ctime())

    # ****** Step #7.3: send events to showcase model ******
    logger.info('****** Step #7.3: send events to showcase model ******')
    sendEventsToShowcase(adminUser, adminPwd, ipAddr, port, sysUname)
