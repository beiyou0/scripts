import os
import logging
import subprocess
import ConfigParser

logger = logging.getLogger('setupEnv.monUtil')

def replaceOnefile(filename, valDict):
    logger.info('--- Method Name: replaceOnefile - filename: ' + filename)
    f = open(filename, 'r+')
    allLines = f.readlines()
    f.seek(0)
    f.truncate()

    for line in allLines:
        for key in valDict:
            line = line.replace(key, valDict.get(key))
        f.write(line)
    f.close()


def runSystemCmd(cmd):
    logger.info('--- Method Name: runSystemCmd - run system command: ' + cmd)
    result = ''
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in p.stdout.readlines():
        result += line
    retval = p.wait()
    return result


def readConfig(filename):
    logger.info('--- Method Name: readConfig - read configuration')
    cf = ConfigParser.ConfigParser()
    cf.read(filename)

    host = cf.get('ftpConfig', 'host')
    dir_root = cf.get('ftpConfig', 'dir_root')
    dirn = cf.get('ftpConfig', 'dirn')
    filelist = cf.get('ftpConfig', 'filelist')
    user = cf.get('ftpConfig', 'user')
    password = cf.get('ftpConfig', 'password')

    dbSchemaName = cf.get('dbConfig', 'dbSchemaName')
    dbName = cf.get('dbConfig', 'dbName')
    dbUserId = cf.get('dbConfig', 'dbUserId')
    dbPassword = cf.get('dbConfig', 'dbPassword')
    dbHost = cf.get('dbConfig', 'dbHost')
    dbPort = cf.get('dbConfig', 'dbPort')
    dbCogName = cf.get('dbConfig', 'dbCogName')
    dbSrvUser = cf.get('dbConfig', 'dbSrvUser')
    dbSrvPwd = cf.get('dbConfig', 'dbSrvPwd')

    adminUser = cf.get('monConfig', 'adminUser')
    adminPwd = cf.get('monConfig', 'adminPwd')
    ipAddr = cf.get('monConfig', 'ipAddr')
    port = cf.get('monConfig', 'WC_defaulthost_secure')

    return host, dir_root, dirn, filelist, user, password,    \
        dbSchemaName, dbName, dbUserId, dbPassword, dbHost, dbPort, dbCogName, dbSrvUser, dbSrvPwd,    \
        adminUser, adminPwd, ipAddr, port