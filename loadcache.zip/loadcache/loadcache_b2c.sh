#!/bin/bash

hostname="pe40.cn.ibm.com"


# 10 users
./request_b2c.sh 100 100 200 218 $hostname tdpbu1 > 1.log &
./request_b2c.sh 101 101 200 218 $hostname tdpbu2 > 2.log &
./request_b2c.sh 102 102 200 218 $hostname tdpbu3 > 3.log &
./request_b2c.sh 103 103 200 218 $hostname tdpbu4 > 4.log &
./request_b2c.sh 104 104 200 218 $hostname tdpbu5 > 5.log &
./request_b2c.sh 105 105 200 218 $hostname tdpbu6 > 6.log &
./request_b2c.sh 106 106 200 218 $hostname tdpbu7 > 7.log &
./request_b2c.sh 107 107 200 218 $hostname tdpbu8 > 8.log &
./request_b2c.sh 108 108 200 218 $hostname tdpbu9 > 9.log &
./request_b2c.sh 109 109 200 218 $hostname tdpbu10 > 10.log &
