#!/bin/bash

hostname="pe40.cn.ibm.com"


# 10 users
./request_b2b.sh 100 100 200 218 $hostname tdpbu1 > 1.log&
./request_b2b.sh 101 101 200 218 $hostname tdpbu2 > 2.log &
./request_b2b.sh 102 102 200 218 $hostname tdpbu3 > 3.log &
./request_b2b.sh 103 103 200 218 $hostname tdpbu4 > 4.log &
./request_b2b.sh 104 104 200 218 $hostname tdpbu5 > 5.log &
./request_b2b.sh 105 105 200 218 $hostname tdpbu6 > 6.log &
./request_b2b.sh 106 106 200 218 $hostname tdpbu7 > 7.log &
./request_b2b.sh 107 107 200 218 $hostname tdpbu8 > 8.log &
./request_b2b.sh 108 108 200 218 $hostname tdpbu9 > 9.log &
./request_b2b.sh 109 109 200 218 $hostname tdpbu10 > 10.log &

## 20 users
# ./request.sh 100 100 200 209 $hostname tdpbu1 &
# ./request.sh 100 100 210 218 $hostname tdpbu2 &

# ./request.sh 101 101 200 209 $hostname tdpbu3 &
# ./request.sh 101 101 210 218 $hostname tdpbu4 &

# ./request.sh 102 102 200 209 $hostname tdpbu5 &
# ./request.sh 102 102 210 218 $hostname tdpbu6 &

# ./request.sh 103 103 200 209 $hostname tdpbu7 &
# ./request.sh 103 103 210 218 $hostname tdpbu8 &

# ./request.sh 104 104 200 209 $hostname tdpbu9 &
# ./request.sh 104 104 210 218 $hostname tdpbu10 &

# ./request.sh 105 105 200 209 $hostname tdpbu11 &
# ./request.sh 105 105 210 218 $hostname tdpbu12 &

# ./request.sh 106 106 200 209 $hostname tdpbu13 &
# ./request.sh 106 106 210 218 $hostname tdpbu14 &

# ./request.sh 107 107 200 209 $hostname tdpbu15 &
# ./request.sh 107 107 210 218 $hostname tdpbu16 &

# ./request.sh 108 108 200 209 $hostname tdpbu17 &
# ./request.sh 108 108 210 218 $hostname tdpbu18 &

# ./request.sh 109 109 200 209 $hostname tdpbu19 &
# ./request.sh 109 109 210 218 $hostname tdpbu20 &


