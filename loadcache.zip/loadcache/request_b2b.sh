#!/bin/bash
## This load all cache scripts is written for B2B scenario
topStart=$1
topEnd=$2
secondStart=$3
secondEnd=$4
hostname=$5
user=$6

start_time=`date +%s`

homepage="https://$hostname/webapp/remote/stores/servlet/TopCategoriesDisplay?storeId=200000"
curl -s -g --create-dirs -o ./$user/topCat/homepage.html --insecure $homepage

# tdp user log on
logon1Url="https://$hostname/webapp/remote/stores/servlet/AjaxLogon"
postStr="storeId=200000&catalogId=3074457345616676668&reLogonURL=http%3A%2F%2F$hostname%2Fwebapp%2Fremote%2Fstores%2Fservlet%2FTopCategoriesDisplay%3FstoreId%3D200000%26urlLangId%3D-1%26urlRequestType%3DBase%26langId%3D-1%26catalogId%3D3074457345616676668&myAcctMain=&fromOrderId=*&toOrderId=.&deleteIfEmpty=*&continue=1&createIfEmpty=1&calculationUsageId=-1&updatePrices=0&errorViewName=AjaxOrderItemDisplayView&previousPage=&returnPage=&URL=RESTOrderCalculate%3FURL%3Dhttps%3A%2F%2F$hostname%2Fwebapp%2Fwcs%2Fstores%2Fservlet%2FTopCategoriesDisplay%3FstoreId%3D200000%26urlLangId%3D-1%26urlRequestType%3DBase%26langId%3D-1%26catalogId%3D3074457345616676668%26calculationUsageId%3D-1%26calculationUsageId%3D-2%26deleteCartCookie%3Dtrue%26page%3D%26catalogId%3D3074457345616676668%26storeId%3D200000%26globalLogIn%3Dtrue&logonId=$user&logonPassword=wcs1admin&rememberMe=false&widgetId=Header_GlobalLogin&requesttype=ajax"
curl --insecure -s --create-dirs -o ./$user/topCat/logon_$user.html -c cookies_$user.txt -d $postStr $logon1Url

logong2Url="https://$hostname/webapp/remote/stores/servlet/TopCategoriesDisplay?catalogId=3074457345616676668&langId=-1&storeId=200000"
curl -s -g --create-dirs -o ./$user/topCat/homepage.html -b cookies_$user.txt --insecure $logong2Url


# request urls using tdp user cookies
for((i=$topStart;i<=$topEnd;i++))
do 
   prodAddend=$((1000000000000+($i-100)*10000))
   topUrl="https://$hostname/webapp/remote/stores/servlet/CategoryDisplay?storeId=200000&urlLangId=-1&beginIndex=0&urlRequestType=Base&categoryId=$i&pageView=grid&langId=-1&catalogId=3074457345616676668"
   #echo "Request top category, id: " $i
   curl -s -g --create-dirs -o ./$user/topCat/topCat$i.html -b cookies_$user.txt --insecure $topUrl

   for((j=$secondStart;j<=$secondEnd;j++))
   do
     echo "loop second category: $j"
     secondUrl="https://$hostname/webapp/remote/stores/servlet/CategoryDisplay?urlRequestType=Base&catalogId=3074457345616676668&categoryId=$i$j&pageView=grid&urlLangId=-1&beginIndex=0&langId=-1&top_category=$i&storeId=200000"
     #echo "Request second category, id: " $i$j
     httpCode2=`curl -s -g --create-dirs -o ./$user/secondCat/2ndCat$i$j.html -b cookies_$user.txt -w %{http_code} --insecure $secondUrl`
     if [ "$httpCode2" != "200" ]; then
        echo "response fail -- 2ndCategory: top:$i, second:$j, httpcode:$httpCode2"
     fi
     for((k=300;k<=309;k++))
     do
       echo "-loop third category: $k"
       thirdUrl="https://$hostname/webapp/remote/stores/servlet/CategoryDisplay?urlRequestType=Base&catalogId=3074457345616676668&top_category2=$i&categoryId=$i$j$k&pageView=grid&urlLangId=-1&beginIndex=0&langId=-1&top_category=$i$j&storeId=200000"
       #echo "Request third category, id: " $i$j$k
       httpCode3=`curl -s -g --create-dirs -o ./$user/thirdCat/3rdCat$i$j$k.html -b cookies_$user.txt -w %{http_code} --insecure $thirdUrl`
       if [ "$httpCode3" != "200" ]; then
         echo "response fail -- 3rdCategory: top:$i, second:$j, third:$k, httpcode:$httpCode3"
       fi    

       # every second category has 500 products, every third category has 50 products
       prodId=$(($prodAddend+($j-200)*500+($k-300)*50))
      
       # need to re-logon user in order to prevent user time out exception(Redirecting to timeout logoff from ProductDisplay)
       logon1Url="https://$hostname/webapp/remote/stores/servlet/AjaxLogon"
       postStr="storeId=200000&catalogId=3074457345616676668&reLogonURL=http%3A%2F%2F$hostname%2Fwebapp%2Fremote%2Fstores%2Fservlet%2FTopCategoriesDisplay%3FstoreId%3D200000%26urlLangId%3D-1%26urlRequestType%3DBase%26langId%3D-1%26catalogId%3D3074457345616676668&myAcctMain=&fromOrderId=*&toOrderId=.&deleteIfEmpty=*&continue=1&createIfEmpty=1&calculationUsageId=-1&updatePrices=0&errorViewName=AjaxOrderItemDisplayView&previousPage=&returnPage=&URL=RESTOrderCalculate%3FURL%3Dhttps%3A%2F%2F$hostname%2Fwebapp%2Fwcs%2Fstores%2Fservlet%2FTopCategoriesDisplay%3FstoreId%3D200000%26urlLangId%3D-1%26urlRequestType%3DBase%26langId%3D-1%26catalogId%3D3074457345616676668%26calculationUsageId%3D-1%26calculationUsageId%3D-2%26deleteCartCookie%3Dtrue%26page%3D%26catalogId%3D3074457345616676668%26storeId%3D200000%26globalLogIn%3Dtrue&logonId=$user&logonPassword=wcs1admin&rememberMe=false&widgetId=Header_GlobalLogin&requesttype=ajax"
       curl --insecure -s --create-dirs -o ./$user/topCat/logon_$user.html -c cookies_$user.txt -d $postStr $logon1Url
       
       for((l=0;l<=49;l++))
       do
         #echo "Request product url, product id: " $prodId
         prodUrl="https://$hostname/webapp/remote/stores/servlet/ProductDisplay?top_category5=&top_category4=&top_category3=&urlRequestType=Base&productId=$prodId&catalogId=3074457345616676668&top_category2=[Ljava.lang.String%3B%40a0d0ffc1&categoryId=$i$j$k&errorViewName=ProductDisplayErrorView&urlLangId=-1&langId=-1&top_category=$i&parent_category_rn=$i$j&storeId=200000"
         httpCode4=`curl -s -g --create-dirs -o ./$user/prodCat/prod$prodId.html -b cookies_$user.txt -w %{http_code} --insecure $prodUrl`
         if [ "$httpCode4" != "200" ]; then
           echo "response fail -- product: top:$i, second:$j, third:$k, product:$prodId, httpcode:$httpCode4"
         fi
         ((prodId++))
       done
     done
   done 
done

end_time=`date +%s`
duration=$((end_time-start_time))

echo "finished -- topCategory: $topStart-$((i-1)), secondCategory: $secondStart-$((j-1)), duration: $duration (s)" >> loadcache.log
