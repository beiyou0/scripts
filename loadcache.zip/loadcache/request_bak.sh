#!/bin/bash

#curl -o homepage.html --insecure $homePageUrl
#curl -o topCat.html --insecure $topCatUrl
#curl -o thirdCat.html -s --insecure $thirdUrl
hostname="pe40.cn.ibm.com"
prodAddend=$((1000000000000+($1-100)*10000))

homepage="https://$hostname/webapp/remote/stores/servlet/TopCategoriesDisplay?storeId=200000"
curl -s -g $homepage


for((i=100;i<=101;i++))
do
   topUrl="https://$hostname/webapp/remote/stores/servlet/CategoryDisplay?storeId=200000&urlLangId=-1&beginIndex=0&urlRequestType=Base&categoryId=$i&pageView=grid&langId=-1&catalogId=3074457345616676668"
   #echo "Request top category, id: " $i
   #curl -o "topCat$i.html" --insecure $topUrl

   for((j=200;j<=218;j++))
   do
     secondUrl="https://$hostname/webapp/remote/stores/servlet/CategoryDisplay?urlRequestType=Base&catalogId=3074457345616676668&categoryId=$i$j&pageView=grid&urlLangId=-1&beginIndex=0&langId=-1&top_category=$i&storeId=200000"
     #echo "Request second category, id: " $i$j
     #curl -g -o "2ndCat$i$j.html" --insecure $secondUrl
     for((k=300;k<=309;k++))
     do
       thirdUrl="https://$hostname/webapp/remote/stores/servlet/CategoryDisplay?urlRequestType=Base&catalogId=3074457345616676668&top_category2=$i&categoryId=$i$j$k&pageView=grid&urlLangId=-1&beginIndex=0&langId=-1&top_category=$i$j&storeId=200000"
       #echo "Request third category, id: " $i$j$k
       #curl -g -o "3rdCat$i$j$k.html" --insecure $thirdUrl
       
       prodId=$(($prodAddend+($j-200)*500+($k-300)*50))
       for((l=0;l<=49;l++))
       do
         echo "Request product url, product id: " $prodId
         prodUrl="https://$hostname/webapp/remote/stores/servlet/ProductDisplay?top_category5=&top_category4=&top_category3=&urlRequestType=Base&productId=$prodId&catalogId=3074457345616676668&top_category2=[Ljava.lang.String%3B%40a0d0ffc1&categoryId=$i$j$k&errorViewName=ProductDisplayErrorView&urlLangId=-1&langId=-1&top_category=$i&parent_category_rn=$i$j&storeId=200000"
         echo $prodUrl
         curl -g -o "prod$prodId.html" --insecure $prodUrl
        ((prodId++))
       done
     done
   done 
done
